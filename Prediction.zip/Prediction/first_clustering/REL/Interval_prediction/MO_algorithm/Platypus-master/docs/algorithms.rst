==========
Algorithms
==========

NSGA-II
-------

.. autofunction:: platypus.algorithms.NSGAII

NSGA-III
--------

.. autofunction:: platypus.algorithms.NSGAIII

