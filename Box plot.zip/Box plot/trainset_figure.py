import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from chinese_calendar import is_workday,is_holiday,get_holiday_detail
from datetime import datetime
from pandas import Series
from sklearn.metrics import mean_squared_error
from math import sqrt
from statsmodels.tsa.seasonal import seasonal_decompose
import statsmodels
import statsmodels.api as sm
from statsmodels.tsa.arima_model import ARIMA
import seaborn as sns
from sklearn.model_selection import train_test_split
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['Times New Roman']
import holidays

data =pd.read_csv(r'./JFK_hourly_count_fill.csv')

# 使用 np.where 方法
# data['epidemic'] = np.where(data['yes_confirm_1'] < 11, 0, 1)
data['is_rain'] = np.where(data['rain'] == 0, 0, 1)

data['time'] = pd.to_datetime(data['time'])

data['time'] = pd.to_datetime(data.time,yearfirst = True)
# data['year'] = data.time.dt.year
# data['month'] = data.time.dt.month
data['hour'] = data.time.dt.hour

# 获取美国的节假日
us_holidays = holidays.UnitedStates()

# 判断日期是否为工作日或节假日
def Get_Day_Detail(day):
    date = pd.to_datetime(day)
    # 如果是美国节假日
    if date in us_holidays:
        return '节假日'
    # 如果是周末
    elif date.weekday() >= 5:  # 5是周六，6是周日
        return '周六日'
    # 否则为工作日
    else:
        return '工作日'

# 假设 data['time'] 列包含日期信息
data['flag'] = data['time'].apply(lambda x: Get_Day_Detail(x))
data['is_holiday'] = 0
data.loc[data['flag'] == '节假日', 'is_holiday'] = 1
data = data.drop(columns=['flag'])

# data['day'] = data.Datetime.dt.day
# data['Hour'] = data.Datetime.dt.hour
# data['weekofyear'] = data.Datetime.dt.weekofyear
# data['dayofyear'] = data.Datetime.dt.dayofyear
# data['is_workday'] = data['time'].apply(lambda x: is_workday(x))
# data['is_workday'] = data['is_workday'].astype(int)
# data['is_holiday'] = data['time'].apply(lambda x: is_holiday(x))
# data['is_holiday'] = data['is_holiday'].astype(int)
data['day of the week'] = data.time.dt.dayofweek
data.loc[(data['day of the week']==6),'day of the week']=7
data.loc[(data['day of the week']==5),'day of the week']=6
data.loc[(data['day of the week']==4),'day of the week']=5
data.loc[(data['day of the week']==3),'day of the week']=4
data.loc[(data['day of the week']==2),'day of the week']=3
data.loc[(data['day of the week']==1),'day of the week']=2
data.loc[(data['day of the week']==0),'day of the week']=1
def isweekend(row):
    if row.dayofweek == 5 or row.dayofweek == 6:
        return 1
    else:
        return 0
def isweekday(row):
    if row.dayofweek == 5 or row.dayofweek == 6:
        return 0
    else:
        return 1
#temp = train['Datetime']
temp2 = data.time.apply(isweekend)
data['isweekend'] = temp2
temp3 = data.time.apply(isweekday)
# data['isweekday'] = temp3

data.index = data['time']

#独热处理
data= pd.get_dummies(data, columns=["day of the week","hour"])
plt.show()
data = data.drop(data.columns[0], axis=1)
data = data.replace({True: 1, False: 0})
# data.to_csv('data_all.csv')
data.to_csv('final_result_1.csv')

######################################################################################################绘图
data =pd.read_csv(r'./JFK_hourly_count_fill.csv')
X=data.iloc[:,0:]
y=data.iloc[:,1]
data, X_test1, y_train1, y_test1 = train_test_split(X, y, train_size=0.9, shuffle=False)


# 使用 np.where 方法
# data['epidemic'] = np.where(data['yes_confirm_1'] < 11, 0, 1)
data['is_rain'] = np.where(data['rain'] == 0, 0, 1)

data['time'] = pd.to_datetime(data['time'])

data['time'] = pd.to_datetime(data.time,yearfirst = True)
# data['year'] = data.time.dt.year
# data['month'] = data.time.dt.month
data['hour'] = data.time.dt.hour

# 获取美国的节假日
us_holidays = holidays.UnitedStates()

# 判断日期是否为工作日或节假日
def Get_Day_Detail(day):
    date = pd.to_datetime(day)
    # 如果是美国节假日
    if date in us_holidays:
        return '节假日'
    # 如果是周末
    elif date.weekday() >= 5:  # 5是周六，6是周日
        return '周六日'
    # 否则为工作日
    else:
        return '工作日'

# 假设 data['time'] 列包含日期信息
data['flag'] = data['time'].apply(lambda x: Get_Day_Detail(x))
data['is_holiday'] = 0
data.loc[data['flag'] == '节假日', 'is_holiday'] = 1
data = data.drop(columns=['flag'])

# data['day'] = data.Datetime.dt.day
# data['Hour'] = data.Datetime.dt.hour
# data['weekofyear'] = data.Datetime.dt.weekofyear
# data['dayofyear'] = data.Datetime.dt.dayofyear
# data['is_workday'] = data['time'].apply(lambda x: is_workday(x))
# data['is_workday'] = data['is_workday'].astype(int)
# data['is_holiday'] = data['time'].apply(lambda x: is_holiday(x))
# data['is_holiday'] = data['is_holiday'].astype(int)
data['day of the week'] = data.time.dt.dayofweek
data.loc[(data['day of the week']==6),'day of the week']=7
data.loc[(data['day of the week']==5),'day of the week']=6
data.loc[(data['day of the week']==4),'day of the week']=5
data.loc[(data['day of the week']==3),'day of the week']=4
data.loc[(data['day of the week']==2),'day of the week']=3
data.loc[(data['day of the week']==1),'day of the week']=2
data.loc[(data['day of the week']==0),'day of the week']=1
def isweekend(row):
    if row.dayofweek == 5 or row.dayofweek == 6:
        return 1
    else:
        return 0
def isweekday(row):
    if row.dayofweek == 5 or row.dayofweek == 6:
        return 0
    else:
        return 1
#temp = train['Datetime']
temp2 = data.time.apply(isweekend)
data['isweekend'] = temp2
temp3 = data.time.apply(isweekday)
# data['isweekday'] = temp3

data.index = data['time']

plt.figure(1)
sns.histplot(data['xiadan'], bins=100)
plt.xlabel('Order')
plt.savefig('count.pdf')


# 创建画布和子图，设置整体大小
fig, axs = plt.subplots(1, 5, figsize=(15, 5))

# 第一个子图
sns.boxplot(x='day of the week', y='xiadan', data=data, ax=axs[0])
axs[0].set_xlabel("Week", fontsize=15)
axs[0].set_ylabel("Demand order",fontsize=15)
axs[0].tick_params(axis='x', labelsize=15)
axs[0].tick_params(axis='y', labelsize=15)
# 第二个子图
# sns.boxplot(x='month', y='xiadan', data=data, ax=axs[1])
# axs[1].set_xlabel("Month", fontsize=15)
# axs[1].tick_params(axis='x')  # 调整 x 轴标签字体大小
# axs[1].set_ylabel("")
# axs[1].tick_params(axis='x', labelsize=15)
# axs[1].tick_params(axis='y', labelsize=15)

# 第三个子图
sns.boxplot(x='isweekend', y='xiadan', data=data, ax=axs[1])
axs[1].set_xlabel("Is weekend", fontsize=15)
axs[1].set_ylabel("")
axs[1].tick_params(axis='x', labelsize=15)
axs[1].tick_params(axis='y', labelsize=15)

# 第四个子图
sns.boxplot(x='is_holiday', y='xiadan', data=data, ax=axs[2])
axs[2].set_xlabel("Is holiday", fontsize=15)
axs[2].set_ylabel("")
axs[2].tick_params(axis='x', labelsize=15)
axs[2].tick_params(axis='y', labelsize=15)

# 第五个子图
sns.boxplot(x='is_rain', y='xiadan', data=data, ax=axs[3])
axs[3].set_xlabel("Is rain", fontsize=15)
axs[3].set_ylabel("")
axs[3].tick_params(axis='x', labelsize=15)
axs[3].tick_params(axis='y', labelsize=15)


sns.boxplot(x='hour', y='xiadan', data=data, ax=axs[4])
axs[4].set_xlabel("Hour", fontsize=15)
axs[4].tick_params(axis='x')  # 调整 x 轴标签字体大小
axs[4].set_ylabel("")
axs[4].tick_params(axis='x', labelsize=15)
axs[4].tick_params(axis='y', labelsize=15)

plt.tight_layout()
plt.savefig('all_is_jfk.pdf')

#概率分布
plt.figure()
sns.distplot(data['xiadan'], bins=400)
plt.xlabel("Order")
plt.savefig('distribution.pdf')

plt.show()



