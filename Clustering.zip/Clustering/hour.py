import pandas as pd
import matplotlib.pyplot as plt

# 假设已经读取了数据
data = pd.read_csv("./final_result_1_SSA.csv")  # 用实际的文件路径替代

# 将时间列转为 datetime 类型
data['time'] = pd.to_datetime(data['time'])

# 提取日期和小时
data['date'] = data['time'].dt.date
data['hour'] = data['time'].dt.hour

# 创建透视表：日期为行，小时为列，值为 xiadan
pivot_data = data.pivot_table(index='date', columns='hour', values='xiadan', aggfunc='sum', fill_value=0)

# 保存为 CSV 文件
pivot_data.to_csv('xiadan_pivot.csv')
data=pivot_data
# 绘制图表
plt.figure(figsize=(10, 6))
# 设置横坐标范围为 0 到 23 小时
plt.xticks(range(24))
# 为每一行（每一天）绘制一条线
for index, row in data.iterrows():
    plt.plot(data.columns, row, label=str(index))

# 设置图表标题和标签
plt.title('Hourly Data for Each Day')
plt.xlabel('Hour of the Day')
plt.ylabel('Values')

# 添加图例
plt.legend(title="Date", bbox_to_anchor=(1.05, 1), loc='upper left')

# 显示图表
plt.tight_layout()
plt.show()